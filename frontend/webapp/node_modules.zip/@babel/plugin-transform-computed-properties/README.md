# @babel/plugin-transform-computed-properties

> Compile ES2015 computed properties to ES5

See our website [@babel/plugin-transform-computed-properties](https://babeljs.io/docs/en/babel-plugin-transform-computed-properties) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-computed-properties
```

or using yarn:

```sh
yarn add @babel/plugin-transform-computed-properties --dev
```
